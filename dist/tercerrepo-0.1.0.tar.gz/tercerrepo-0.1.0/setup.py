from setuptools import setup, find_packages

setup(
    name='tercerRepo',
    version='0.1.0',
    packages=find_packages(),
    author='Filiberto Flores',
    author_email='floresfiliberto52@gmail.com',
    url='https://github.com/filifloresb/tercerRepo#',
)

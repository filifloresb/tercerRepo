from setuptools import setup, find_packages

setup(
    name='tercer_repo',
    version='0.1',
    packages=find_packages(),
    author='Filiberto Flores',
    author_email='floresfiliberto52@gmail.com',
    url='https://github.com/filifloresb/tercerRepo#',
)
